#Linux Administration
#1. 
cat /var/log/dmesg | sed -n '10,20 p'

#2. 
cat /var/log/dmesg | grep 'systemd\|zone'

#3.
cat /var/log/syslog | awk '{print $1 " " $2}' #(prefferd...)
#or
cat /var/log/syslog | cut -d " " -f1,2

#4.
#shell
cat test.txt | sed -i 's/unix/linux/g' test.txt
#vi
:s/unix/linux/g

#5. 
sudo apt-get install <Package Name>
sudo apt-get remove <Package Name>
sudo apt-get update
sudo apt-get --only-upgrade install <Package Name> 

#6.
sudo apt-get update
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
echo "deb http://apt.postgresql.org/pub/repos/apt/ `lsb_release -cs`-pgdg main" |sudo tee  /etc/apt/sources.list.d/pgdg.list
sudo apt update
sudo apt -y install postgresql-12 postgresql-client-12
psql --version
sudo systemctl status postgresql
#"6 postgresql12 screenshot.PNG" attached file


#7. 
apt-get update = update the list of the availbale Packages version
apt-get upgrafe = upgrage the Packages to the new version

#8.
apt-get update && apt-get upgrade -y

#9.
when you want to install a package the system search the package in the fwe places
1. /etc/apt/sources.list
2. the files with the extention *.list int /etc/apt/sources.list.d/*.list

#10.
sudo df -h
#"10 disk space usage.PNG" attached file
#or to specific folder
sudo du -hs /etc/
#"10 folder size.PNG" attached file

#11.
ps -aux   
ps -A     

#12.
systemctl --type=service
#or
systemctl --type=service

#13.
sudo fdisk /dev/xvdb                                
sudo pvcreate /dev/xvdb1                            
sudo pvs                                            
sudo vgcreate wave-vg /dev/xvdb1                    
sudo vgs                                            
sudo lvcreate wave-lv01 wave-vg                     
sudo lvcreate -n wave-lv01 --size 1G wave-vg        
sudo pvdisplay                                      
sudo lvcreate -n wave-lv01 --size 1000M wave-vg     
sudo lvs                                            
sudo mkfs.ext4 /dev/wave-vg/wave-lv01               
sudo mount /dev/wave-vg/wave-lv01 /avraham-mount/   
sudo touch /avraham-mount/testFileOnAvrahamMount    
ls -l /avraham-mount/                               

#"13 mounted lvm.PNG" attached file
#"13 Mount After reboot.PNG" attached file
#"13 fstab.PNG" attached file


#---------------------
#Ansible 
#1.
#"Ansible 1.PNG" attached file


                                             